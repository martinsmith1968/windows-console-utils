From: 4.24
From Version 4.24 by default, the DesktopOK.ini will be created in the folder %APPDATA%/DesktopOK
For portable use, please create or copy in DesktopOK working directory the DesktopOK.ini.

To run DesktopOK as a portable program you should create an empty
DesktopOK.ini in the same directory as DesktopOK.exe. 

