By default, the TheAeroClock.ini will be created in the folder %APPDATA%/TheAeroClock

For portable use, please create or copy in TheAeroClock working directory the TheAeroClock.ini.

Or run an portable_install!

Program Arguments (Command Line)
-?uninstall
-?install
-?portable_install


Rename:
TheAeroClock.exe 
TheAeroClock_Install.exe 
TheAeroClock_Portable_Install.exe
 