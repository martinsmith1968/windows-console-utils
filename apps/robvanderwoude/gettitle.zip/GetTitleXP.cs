﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace RobvanderWoude
{
	class GetTitle
	{
		// DLL imports required to read window title
		[DllImport( "kernel32.dll", CharSet = CharSet.Auto, SetLastError = true )]
		internal static extern int GetConsoleTitle( StringBuilder sb, int capacity );

		static int Main( string[] args )
		{
			try
			{
				// Check command line arguments (none required)
				switch ( args.Length )
				{
					case 0:
						break;
					case 1:
						switch ( args[0].ToLower( ) )
						{
							case "/?":
							case "-?":
							case "/h":
							case "-h":
							case "/help":
							case "-help":
							case "--help":
								// Display help text without error message
								throw new Exception( string.Empty );
							default:
								throw new Exception( "Invalid command line argument" );
						}
					default:
						// Display help text with error message
						throw new Exception( "Invalid command line arguments" );
				}

				// Read and display the window title
				Console.WriteLine( GetWindowTitle( ) );

				return 0;
			}
			catch ( Exception e )
			{
				return WriteError( e );
			}
		}

		// Code to read window title, by Justin Goldspring
		public static string GetWindowTitle( )
		{
			const int nChars = 256;
			IntPtr handle = IntPtr.Zero;
			StringBuilder Buff = new StringBuilder( nChars );

			if ( GetConsoleTitle( Buff, nChars ) > 0 )
			{
				return Buff.ToString( );
			}
			return string.Empty;
		}

		public static int WriteError( Exception e )
		{
			return WriteError( e == null ? null : e.Message );
		}
		
		public static int WriteError( string errorMessage )
		{
			string fullpath = Environment.GetCommandLineArgs( ).GetValue( 0 ).ToString( );
			string[] program = fullpath.Split( '\\' );
			string exeName = program[program.GetUpperBound( 0 )];
			exeName = exeName.Substring( 0, exeName.IndexOf( '.' ) );

			/*
			GetTitleXP,  Version 3.05 for Windows XP
			Return the current window's title

			Usage:    GETTITLEXP

			Credits:  Code to read console window title by Justin Goldspring.

			Written by Rob van der Woude
			http://www.robvanderwoude.com
			*/

			if ( string.IsNullOrEmpty( errorMessage ) == false )
			{
				Console.Error.WriteLine( );
				Console.ForegroundColor = ConsoleColor.Red;
				Console.Error.Write( "ERROR: " );
				Console.ForegroundColor = ConsoleColor.White;
				Console.Error.WriteLine( errorMessage );
				Console.ResetColor( );
			}

			Console.Error.WriteLine( );
			Console.Error.WriteLine( "GetTitleXP,  Version 3.05 for Windows XP" );
			Console.Error.WriteLine( "Return the current window's title" );
			Console.Error.WriteLine( );
			Console.Error.Write( "Usage:    " );
			Console.ForegroundColor = ConsoleColor.White;
			Console.Error.WriteLine( exeName.ToUpper( ) );
			Console.ResetColor( );
			Console.Error.WriteLine( );
			Console.Error.WriteLine( "Credits:  Code to read console window title by Justin Goldspring." );
			Console.Error.WriteLine( );
			Console.Error.WriteLine( "Written by Rob van der Woude" );
			Console.Error.WriteLine( "http://www.robvanderwoude.com" );
			return 1;
		}
	}
}