

Network Speed [Version 1.40]

Calculates the network speed (transfer rate) between two winsock hosts.


The syntax of this command is:


NetSpeed /H:host|/S[:n] [/P:n] [/M:n] [/C:y|n]

 /H:host  : Client mode, host=name/address of a machine waiting in server mode.
 /S:n     : Server mode, n=# of times to answer before exiting, default is 9999
 /P:n     : n=Port number, default is 7777.  (Both client & server must match)
 /M:n     : n=Megabytes to transfer, default is 10. (Only valid in client mode)
 /C:y,/C:n: y=The data sent will be compressible; n=Not compressible (default).

Copyright 1999-2002 Marty List, Marty@OptimumX.com


==================================================================


System Requirements:
	Windows XP; 2000; NT; ME; 98; 95
	TCP/IP and Winsock installed.


Revision History:
	1.40 	10/01/2002
	Added the /C command-line switch for compression.

	1.30 	09/07/2000
	Minor interface enhancements.

	1.10 	01/08/2000
	Minor interface enhancements.

	1.00	11/15/1999
	Initial release.
