
Memory Check [Version 1.00]

Displays information about the system's current memory statistics.  Also allows
you to commit and lock memory, to experiment with how much virtual and physical
memory is currently available to new processes.


The syntax of this command is:

MemCheck [/commit:#] [/lock]

 /COMMIT: Allows you to commit a specified size of memory (in megabytes).
          The maximum value allowed is 4095.
 /LOCK causes the memory specified with /COMMIT to be locked into physical
       memory.  This ensures that subsequent access to the region will
       not incur a page fault.


Examples:
  MemCheck /commit:1024
  MemCheck /commit:512 /lock

Legend:
  1KB=1024 Bytes; 1MB=1024 KB; 1GB=1024 MB

An argument of /? or -? displays this syntax and always returns 1.
A successful completion will return 0.

Copyright 2004 Marty List, www.optimumx.com


===============================================================================


System Requirements:

	Windows Server 2003; Windows XP; Windows 2000; Windows NT


Revision History:

	1.00 	07/20/2004
	Initial release.
