

Set Wallpaper version 1.10

Sets the desktop wallpaper and updates the current user profile.


Syntax:   SetWallpaper.exe [/D:C|T|S] filename.bmp|/R

Examples: SetWallpaper.exe C:\Downloads\Pamela.bmp
          SetWallpaper.exe /D:T C:\Downloads\Carmen.bmp
          SetWallpaper.exe /r


The last parameter should be either the bitmap filename or /R

An argument of /R will remove the desktop wallpaper.
An argument of /D: allows you to display the image Centered, Tiled or Stretched

An argument of /? or -? displays this syntax and always returns 1.
A successful completion will return 0.


Copyright 1999-2000 Marty List, OptimumX@usa.net


==================================================================


Revision History:
1.10 	11/21/2000
Added /D: option to display the image centered, tiled or stretched.

1.00 	08/25/1999
Initial release.
