
Set Short File Name [Version 1.00]


 Sets the 8.3 SFN (Short File Name) for the specified file or folder.
 Requires Windows XP or later.


 Syntax: SetSFN.exe /F:filename [/SFN:shortname] [/Y]

 /F:    Specifies an existing file or folder to modify.
 /SFN:  Specifies the new short name.  Must be a valid 8.3 format name.
 /Y     Suppresses the 'Are you sure' prompt.

 /? or -? displays this syntax and always returns 1.
 A successful completion returns 0.


Copyright 2003 Marty List, www.optimumx.com


==================================================================


System Requirements:

	Windows XP; Windows Server 2003 or later.


Revision History:

	1.00 	05/17/2003
	Initial release.
