
iniTool [Version 1.20]

Queries sections and keys from INI formatted files.


The syntax of this command is:

iniTool.exe /f:filename [/s:section] [/k:key]

 /f: Path to an INI format file.
 /s: Section name. If not specified, all sections are returned.
 /k: Key name. If not specified, all keys in /s:section are returned.


Notes:
  Use double quotes if any of the names contain spaces.
  Results can differ from the file contents, because some values are mapped
  to the Registry. For more info see Microsoft Knowledge Base article KB102889.

Examples:
  iniTool.exe /f:X:\FolderName\FileName.ini
  iniTool.exe /f:X:\FolderName\FileName.ini /s:Section1
  iniTool.exe /f:X:\FolderName\FileName.ini /s:Section1 /k:Key1
  iniTool.exe /f:"X:\Folder Name\File Name.ini" /s:"Section 2" /k:"Key 2"


An argument of /? or -? displays this syntax and always returns 1.
A successful completion will return 0.

Copyright 2003-2010 Marty List, www.optimumx.com


==================================================================


System Requirements:

	Windows Server 2008 R2; Windows Server 2008; Windows Server 2003 R2; Windows Server 2003
	Windows 7; Windows Vista; Windows XP; Windows 2000; Windows NT
	Windows ME; Windows 98; Windows 95


Revision History:

	1.20 	07/02/2010
	Increased the internal buffer size to support larger files.
	Added additional exit codes and error messages.
	
	1.10 	03/14/2004
	Added the ability to return all sections or keys.
	Exit codes 2 and 3 are returned for invalid file names/paths.
	
	1.00 	05/21/2003
	Initial release.
