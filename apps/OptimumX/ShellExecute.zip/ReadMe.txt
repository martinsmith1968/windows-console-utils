
Shell Execute [version 1.00]

Launches executables or documents according to their file type association.


The syntax of this command is:

ShellExecute.exe /F:file [/P:parameters /W:workingdir /R:runstyle /A:action]

 /F:	Specifies the file to execute.
 /P:	Defines the command-line parameters to pass to the executable.
 /W:	Defines the working directory the executable starts with.
 /R:	Defines the window state, default is normal. (/r:Min|Max|Hidden).
 /A:	Defines the action to take, default is Open (Print, Explore, etc.)

Examples:
ShellExecute.exe /f:D:\\Setup.exe /p:-S -SMS /r:hidden
ShellExecute.exe /f:C:\\Boot.ini /a:print

An argument of /? displays this syntax and returns 1.
A successful completion will return 0.


Copyright 2001 Marty List, OptimumX@usa.net
