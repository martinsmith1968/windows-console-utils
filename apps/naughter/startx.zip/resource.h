//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by StartX.rc
//
#define IDP_FAIL_RUN_CREATEPROCESS      1
#define IDP_PROMPT_FOR_PARAMETERS       2
#define IDP_FAIL_RUN_GETNUMANODEPROCESSORMASKEX 4
#define IDP_FAIL_RUN_CREDUIPROMPTFORCREDENTIALS 5
#define IDS_MESSAGE_PROMPT              6
#define IDS_MESSAGE_CAPTION             7
#define IDP_FAIL_RUN_HELP               8
#define IDP_FAIL_SET_PROCESS_AFFINITY   9
#define IDD_PARAMETERS_PROMT            103
#define IDR_MAINFRAME                   128
#define IDI_MYEXCLAMATION               129
#define IDC_MYHELP                      1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
