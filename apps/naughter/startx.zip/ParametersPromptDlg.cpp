#include "stdafx.h"
#include "StartX.h"
#include "ParametersPromptDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#pragma warning(suppress: 26455)
CParametersPromptDlg::CParametersPromptDlg(_In_opt_ CWnd* pParent) : CDialog{CParametersPromptDlg::IDD, pParent}
{
}

#pragma warning(suppress: 26433 26440)
BEGIN_MESSAGE_MAP(CParametersPromptDlg, CDialog) //NOLINT(clang-diagnostic-unused-local-typedef, modernize-avoid-c-arrays)
  ON_BN_CLICKED(IDC_MYHELP, &CParametersPromptDlg::OnMyHelp)
END_MESSAGE_MAP()

void CParametersPromptDlg::OnMyHelp()
{
  //Form the name of the html file we will be showing for help
  CString sFilename;
  const DWORD dwGMF{GetModuleFileName(nullptr, sFilename.GetBuffer(_MAX_PATH), _MAX_PATH)};
  sFilename.ReleaseBuffer();
  if (dwGMF == 0)
    return;
  CString sDrive;
  CString sDir;
  CString sFname;
  _tsplitpath_s(sFilename, sDrive.GetBuffer(_MAX_DRIVE), _MAX_DRIVE, sDir.GetBuffer(_MAX_DIR), _MAX_DIR, sFname.GetBuffer(_MAX_FNAME), _MAX_FNAME, nullptr, 0);
  _tmakepath_s(sFilename.GetBuffer(_MAX_PATH), _MAX_PATH, sDrive, sDir, sFname, _T("HTM"));
  sFilename.ReleaseBuffer();

  //Show the html file
#pragma warning(suppress: 26462)
  HINSTANCE hRun{ShellExecute(AfxGetMainWnd()->m_hWnd, _T("open"), sFilename, nullptr, nullptr, SW_SHOW)};
#pragma warning(suppress: 26490)
  if (reinterpret_cast<INT_PTR>(hRun) <= 32)
    AfxMessageBox(IDP_FAIL_RUN_HELP, MB_OK | MB_ICONEXCLAMATION);
}
