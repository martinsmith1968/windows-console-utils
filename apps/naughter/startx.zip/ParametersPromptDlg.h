#pragma once

#include "resource.h"


class CParametersPromptDlg : public CDialog
{
public:
//Constructors / Destructors
  CParametersPromptDlg(_In_opt_ CWnd* pParent = nullptr);
  CParametersPromptDlg(const CParametersPromptDlg&) = delete;
  CParametersPromptDlg(CParametersPromptDlg&&) = delete;
  ~CParametersPromptDlg() = default; //NOLINT(modernize-use-override)

//Methods
  CParametersPromptDlg& operator=(const CParametersPromptDlg&) = delete;
  CParametersPromptDlg& operator=(CParametersPromptDlg&&) = delete;

//Member variables
  enum { IDD = IDD_PARAMETERS_PROMT };

protected:
//Message handlers
  afx_msg void OnMyHelp();

  DECLARE_MESSAGE_MAP()
};
