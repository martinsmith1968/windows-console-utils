/*
Module : StartX.cpp
Purpose: Implementation of a simple CreateProcess wrapper app
Created: PJN / 29-01-2003
History: PJN / 20-08-2004 1. Now returns the error code back to the OS as returned from any failures when calling 
                          the Win32 SDK calls which StartX uses.
                          2. Now includes a /NOUI command line parameter, which suppresses any messages boxes which 
                          can appear when an error occurs. Thanks to Trevor Hart for these 2 suggestions.
         PJN / 20-12-2004 1. Now supports a /RETURNERROR command line parameter, which returns the error code of
                          the process being run. Setting this parameter implies using /WAIT. Thanks to 
                          "ITAKA webmaster" for suggesting this addition.
         PJN / 19-08-2005 1. Error codes are now reported as a string by calling FormatMessage. Thanks to 
                          Dennis Bareis for prompting this update.
                          2. String resources which are displayed to the end user now use the format IDP_...
         PJN / 17-07-2006 1. Updated copyright details.
                          2. Optimized CMyCommandLineInfo constructor code
                          3. Code now uses new C++ style casts rather than old style C casts where necessary.
                          4. CSIDL folders parameter replacement now uses the value @CSIDLnumber@ instead of just
                          @number@. This avoids problems where you need to pass a real "@" onto the application 
                          being controlled. Thanks to Ramon Hansman for reporting this issue.
                          5. Updated the documentation to use the same style as the web site.
                          6. Replaced all calls to ZeroMemory with memset
                          7. Code now securely deletes the domain, username and password strings once they have been used.
                          8. Updated the code to clean compile on VC 2005
                          9. The code now requires the Platform SDK if compiled using VC 6.
                          10. Code now uses SHGFP_TYPE_CURRENT instead of SHGFP_TYPE_DEFAULT when calling 
                          SHGetFolderPath.
                          11. Fixed a coding error where CStartXApp::InitInstance returned TRUE instead of FALSE.
                          12. CreateProcessWithLogonW is now used if a username is specified or if the prompt password
                          command line option is set.
         PJN / 08-02-2008 1. Updated copyright details.
                          2. Removed VC 6 style AppWizard comments from the code
                          3. Updated the code to clean compile on VC 2008
                          4. The code and shipped exe has been updated to take advantage of VC 2005 specific coding techniques.
                          In fact the shipped exe in the zip was compiled with VC 2005 SP1.
                          5. CStartXApp::GetErrorMessage now uses the FORMAT_MESSAGE_IGNORE_INSERTS flag. For more information 
                          please see Raymond Chen's blog at http://blogs.msdn.com/oldnewthing/archive/2007/11/28/6564257.aspx. 
                          Thanks to Alexey Kuznetsov for reporting this issue.
         PJN / 11-11-2008 1. Code now compiles cleanly using Code Analysis (/analyze)
                          2. Updated code to compile correctly using _ATL_CSTRING_EXPLICIT_CONSTRUCTORS define
                          3. The code has now been updated to support VC 2005 or later only.  
                          4. StartX can now set the process affinity mask via the new AFFINITY command line option. The value 
                          you provide here is the value passed to SetProcessAffinityMask. So for example if you wanted to limit
                          the new process to only run on the 2nd and 3rd CPU only of a computer then you would use the command
                          line "/AFFINITY6". i.e. 0x2 & 0x4. Probably the most common value you would use for this would be 
                          "/AFFINITY1" which would limit the process to run on the first CPU only. Please note that the value
                          you provide on the command line should be decimal and not hexadecimal. Thanks to "Cobus" for prompting 
                          this update.
         PJN / 22-05-2016 1. Updated copyright details.
                          2. Update the project settings to more modern defaults
                          3. Updated the code to clean compile on VC 2010 - VC 2015
                          4. CMyCommandLineInfo::GetIdlPath now calls ShGetFolderPath directly instead of through GetProcAddress.
                          5. Code now calls CreateProcessWithLogonW directly instead of through GetProcAddress
                          6. Code now calls CredUIPromptForCredentials directly instead of through GetProcAddress
                          7. Reviewed the documentation's description of all the CSIDL values and made sure it was up to date.
                          8. StartX now supports a /HIDE command line option.
                          9. StartX now supports a /NODE command line option similar to the internal Start Windows command
                          10. StartX now supports a /PREVENTPINNING command line option.
                          11. StartX now supports a /TITLEISAPPID command line option.
                          12. StartX now supports a /TITLEISLINKNAME command line option.
                          13. StartX now supports a /UNTRUSTEDSOURCE command line option.
         PJN / 05-06-2016 1. Updated documentation for the /TITLEISAPPID, /TITLEISLINKNAME & /UNTRUSTEDSOURCE parameters. Thanks 
                          to Marc Kupper for reporting this issue.
                          2. Updated documentation to remove double reference to /NOUI. Thanks to Marc Kupper for reporting this 
                          issue.
                          3. Removed documentation reference to /I command line parameter. Thanks to Marc Kupper for reporting 
                          this issue.
                          4. Updated documentation to refer to /MIN, /MAX & /HIDE as mutually exclusive. Thanks to Marc Kupper 
                          for reporting this issue.
                          5. Updated documentation to refer to /LP & /LNCO as mutually exclusive. Thanks to Marc Kupper for 
                          reporting this issue.
                          6. Updated documentation for parameters to be in the same order in the parameters list and the 
                          description table. Thanks to Marc Kupper for reporting this issue. 
                          7. Added code to support the /REALTIME parameter. Thanks to Marc Kupper for reporting this issue.
         PJN / 05-12-2017 1. Updated copyright details
                          2. Replaced NULL throughout the codebase with nullptr.
                          3. Replaced BOOL throughout the codebase with bool.
                          4. Replaced CString::operator LPC*STR() calls throughout the codebase with CString::GetString calls
                          5. GetNumaNodeProcessorMaskEx is now called directly rather than via GetProcAddress. This means
                          that the minimum supported version of Windows is Windows 7.
                          6. CMyCommandLineInfo::GetIdlPath has been reworked and renamed to work with KNOWNFOLDERID values 
                          instead of CSIDL values.
         PJN / 17-10-2018 1. Updated copyright details.
                          2. Fixed a number of C++ core guidelines compiler warnings. These changes mean that the code will 
                          now only compile on VC 2017 or later.
         PJN / 01-06-2018 1. Updated copyright details.
                          2. Updated the code to clean compile on VC 2019
         PJN / 16-11-2019 1. Updated initialization of various structs to use C++ 11 list initialization
         PJN / 29-12-2019 1. Fixed various Clang-Tidy static code analysis warnings in the code.
         PJN / 05-04-2020 1. Updated copyright details.
                          2. Fixed more Clang-Tidy static code analysis warnings in the code.
         PJN / 27-05-2022 1. Updated copyright details.
                          2. Updated the code to use C++ uniform initialization for all variable declarations.

Copyright (c) 2003 - 2022 by PJ Naughter (Web: www.naughter.com, Email: pjna@naughter.com)

All rights reserved.

Copyright / Usage Details:

You are allowed to include the source code in any product (commercial, shareware, freeware or otherwise) 
when your product is released in binary form. You are allowed to modify the source code in any way you want 
except you cannot modify the copyright details at the top of each module. If you want to distribute source 
code with your application, then you are only allowed to distribute versions released by the author. This is 
to maintain a single distribution point for the source code. 

*/


//////////////////// Includes /////////////////////////////////////////////////

#include "stdafx.h"
#include "StartX.h"
#include "ParametersPromptDlg.h"


//////////////////// Macros / Locals //////////////////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG


//The one and only CWinApp derived instance
#pragma warning(suppress: 26426)
CStartXApp theApp;


//////////////////// Implementation ///////////////////////////////////////////

class CMyCommandLineInfo : public CCommandLineInfo
{
public:
//Methods
  void FixStrings(_Inout_ CString& sValue);
  void ParseParam(const TCHAR* lpszParam, BOOL bFlag, BOOL bLast) override;
  CString MapFromGenericPath(_In_ const CString& sPath);
  CString GetKnownFolderPath(_In_ REFKNOWNFOLDERID rfid);

//Data
  CString sUser; //The user to run the request as
  CString sDomain; //The domain of the user to run the request as
  bool bPromptPassword{false}; //Should we prompt for the users password
  CString sPassword; //The password for "sUser" to login with
  CString sCommandLine; //The command line to actually run
  DWORD dwCreationFlags{0}; //The creation flags to pass to "CreateProcess.."
  CString sDesktop; //The "lpDesktop" attribute in the STARTUPINFO structure
  bool bDesktop{false}; //true if the "lpDesktop" attribute should be used
  CString sConsoleTitle; //The "lpTitle" attribute in the STARTUPINFO structure
  CPoint WindowPoint; //The x and y values of the "dwX" and "dwY" attributes in the STARTUPINFO structure
  CSize WindowSize{0, 0}; //The width and height values of the "dwXSize" and "dwYSize" attributes in the STARTUPINFO structure
  CSize ConsoleBufferSize{0, 0}; //The width and height values of the "dwXCountChars" and "dwYCountChars" attributes in the STARTUPINFO structure
  DWORD dwFillAttribute{0}; //The "dwFillAttribute" attribute in the STARTUPINFO structure
  DWORD dwFlags{0}; //The "dwFlags" attribute in the STARTUPINFO structure
  WORD wShowWindow{SW_SHOW}; //The "wShowWindow" attribute in the STARTUPINFO structure
  CString sCurrentDirectory; //The "lpCurrentDirectory" attribute to pass to "CreateProcess.."
  DWORD dwLogonFlags{0}; //The "dwLogonFlags" attribute to pass to "CreateProcessWithLogonW"
  bool bWait{false}; //Should we wait for the process to terminate before this app exits
  CString sDrive; //The value which is replaced in all occurrences of "@EXEDRV@"
  CString sFolder; //The value which is replaced in all occurrences of "@EXEDIR@"
  bool bNoUI{false}; //Supress any GUI
  bool bReturnError{false}; //Returns error code in process being created
  DWORD_PTR dwProcessAffinity{0}; //The processor affinity mask to use. A value of 0 which would be invalid means do not set
  int nNode{-1}; //The NUMA node to use. A value of -1 which would be invalid means do not set
};


void CMyCommandLineInfo::FixStrings(_Inout_ CString& sValue)
{
  //Replace any variables with their actual values as determined above
  sValue.Replace(_T("@EXEDRV@"), sDrive);
  sValue.Replace(_T("@EXEDIR@"), sFolder);
  sValue.Replace(_T("@QUOTE@"), _T("\""));
  sValue = MapFromGenericPath(sValue);
}

CString CMyCommandLineInfo::MapFromGenericPath(_In_ const CString& sPath)
{
  CString sExpanded{sPath};
  int nQuote1{sExpanded.Find(_T("@KFID"))};
  while (nQuote1 != -1)
  {
    CString sGeneric{sExpanded.Mid(nQuote1 + 5)};
    const int nQuote2{sGeneric.Find(_T('@'))};
    if (nQuote2 > 0)
    {
      CStringW sGUID{sGeneric.Left(nQuote2)};
#pragma warning(suppress: 26496)
      KNOWNFOLDERID FolderID{GUID_NULL};
      const HRESULT hr{CLSIDFromString(sGUID, &FolderID)};
      UNREFERENCED_PARAMETER(hr);
#pragma warning(suppress: 6102)
      sExpanded = sExpanded.Left(nQuote1) + GetKnownFolderPath(FolderID) + sExpanded.Right(sExpanded.GetLength() - nQuote2 - nQuote1 - 6);
    }

    //Prepare for the next time around
    nQuote1 = sExpanded.Find(_T("@KFID"));
  }

  return sExpanded;
}

CString CMyCommandLineInfo::GetKnownFolderPath(_In_ REFKNOWNFOLDERID rfid)
{
  //What will be the return value
  CString sIdl;

  PWSTR pszPath{nullptr};
  if (SUCCEEDED(SHGetKnownFolderPath(rfid, 0, nullptr, &pszPath)))
  {
    sIdl = pszPath;
    CoTaskMemFree(pszPath);
  }

  return sIdl;
}

#pragma warning(suppress: 26429)
void CMyCommandLineInfo::ParseParam(const TCHAR* lpszParam, BOOL bFlag, BOOL bLast)
{
  CString sUpCaseParam{lpszParam};
  sUpCaseParam.MakeUpper();
  const int nLength{sUpCaseParam.GetLength()};

  if (!bFlag) //NOLINT(clang-analyzer-core.CallAndMessage)
  {
    if (!bLast)
    {
      sConsoleTitle = lpszParam;
      FixStrings(sConsoleTitle);
    }
    else
    {
      sCommandLine = lpszParam;
      FixStrings(sCommandLine);
    }
  }
  else
  {
    if (nLength && sUpCaseParam.GetAt(0) == _T('D'))
    {
      sCurrentDirectory = CString(lpszParam).Mid(1);
      FixStrings(sCurrentDirectory);
    }
    else if (sUpCaseParam == _T("B"))
      dwCreationFlags |= CREATE_NO_WINDOW;
    else if (sUpCaseParam == _T("NOUI"))
      bNoUI = true;
    else if (sUpCaseParam == _T("RETURNERROR"))
    {
      bReturnError = true;
      bWait = true;
    }
    else if (sUpCaseParam == _T("PP"))
      bPromptPassword = true;
    else if (sUpCaseParam == _T("MIN"))
    {
      dwFlags |= STARTF_USESHOWWINDOW;
      wShowWindow = SW_SHOWMINIMIZED;
    }
    else if (sUpCaseParam == _T("MAX"))
    {
      dwFlags |= STARTF_USESHOWWINDOW;
      wShowWindow = SW_SHOWMAXIMIZED;
    }
    else if (sUpCaseParam == _T("HIDE"))
    {
      dwFlags |= STARTF_USESHOWWINDOW;
      wShowWindow = SW_HIDE;
    }
    else if (sUpCaseParam == _T("SEPARATE"))
      dwCreationFlags |= CREATE_SEPARATE_WOW_VDM;
    else if (sUpCaseParam == _T("SHARED"))
      dwCreationFlags |= CREATE_SHARED_WOW_VDM;
    else if (sUpCaseParam == _T("LOW"))
      dwCreationFlags |= IDLE_PRIORITY_CLASS;
    else if (sUpCaseParam == _T("NORMAL"))
      dwCreationFlags |= NORMAL_PRIORITY_CLASS;
    else if (sUpCaseParam == _T("HIGH"))
      dwCreationFlags |= HIGH_PRIORITY_CLASS;
    else if (sUpCaseParam == _T("ABOVENORMAL"))
      dwCreationFlags |= ABOVE_NORMAL_PRIORITY_CLASS;
    else if (sUpCaseParam == _T("BELOWNORMAL"))
      dwCreationFlags |= BELOW_NORMAL_PRIORITY_CLASS;
    else if (sUpCaseParam == _T("REALTIME"))
      dwCreationFlags |= REALTIME_PRIORITY_CLASS;
    else if (sUpCaseParam == _T("WAIT"))
      bWait = true;
    else if (sUpCaseParam == _T("PREVENTPINNING"))
      dwFlags |= (STARTF_PREVENTPINNING | STARTF_TITLEISAPPID);
    else if (sUpCaseParam == _T("TITLEISAPPID"))
      dwFlags |= STARTF_TITLEISAPPID;
    else if (sUpCaseParam == _T("TITLEISLINKNAME"))
      dwFlags |= STARTF_TITLEISLINKNAME;
    else if (sUpCaseParam == _T("UNTRUSTEDSOURCE"))
      dwFlags |= STARTF_UNTRUSTEDSOURCE;
    else if ((sUpCaseParam.Find(_T("U")) == 0) && (nLength > 1))
      sUser = CString{lpszParam}.Mid(1);
    else if ((sUpCaseParam.Find(_T("W")) == 0) && (nLength > 1))
      sPassword = CString{lpszParam}.Mid(1);
    else if ((sUpCaseParam.Find(_T("O")) == 0) && (nLength > 1))
      sDomain = CString{lpszParam}.Mid(1);
    else if ((sUpCaseParam.Find(_T("K")) == 0))
    {
      bDesktop = true;
      if (nLength > 1)
        sDesktop = CString{lpszParam}.Mid(1);
    }
    else if ((sUpCaseParam.Find(_T("P")) == 0) && (nLength > 3))
    {
      dwFlags |= STARTF_USEPOSITION;
      CString sPoint{sUpCaseParam.Right(nLength - 1)};
      _stscanf_s(sPoint, _T("%d,%d"), &WindowPoint.x, &WindowPoint.y);
    }
    else if ((sUpCaseParam.Find(_T("S")) == 0) && (nLength > 3))
    {
      dwFlags |= STARTF_USESIZE;
      CString sSize{sUpCaseParam.Right(nLength - 1)};
      _stscanf_s(sSize, _T("%d,%d"), &WindowSize.cx, &WindowSize.cy);
    }
    else if ((sUpCaseParam.Find(_T("CS")) == 0) && (nLength > 4))
    {
      dwFlags |= STARTF_USECOUNTCHARS;
      CString sConsoleSize{sUpCaseParam.Right(nLength - 2)};
      _stscanf_s(sConsoleSize, _T("%d,%d"), &ConsoleBufferSize.cx, &ConsoleBufferSize.cy);
    }
    else if (sUpCaseParam == _T("FR"))
    {
      dwFlags |= STARTF_USEFILLATTRIBUTE;
      dwFillAttribute |= FOREGROUND_RED;
    }
    else if (sUpCaseParam == _T("FG"))
    {
      dwFlags |= STARTF_USEFILLATTRIBUTE;
      dwFillAttribute |= FOREGROUND_GREEN;
    }
    else if (sUpCaseParam == _T("FB"))
    {
      dwFlags |= STARTF_USEFILLATTRIBUTE;
      dwFillAttribute |= FOREGROUND_BLUE;
    }
    else if (sUpCaseParam == _T("BR"))
    {
      dwFlags |= STARTF_USEFILLATTRIBUTE;
      dwFillAttribute |= BACKGROUND_RED;
    }
    else if (sUpCaseParam == _T("BG"))
    {
      dwFlags |= STARTF_USEFILLATTRIBUTE;
      dwFillAttribute |= BACKGROUND_GREEN;
    }
    else if (sUpCaseParam == _T("BB"))
    {
      dwFlags |= STARTF_USEFILLATTRIBUTE;
      dwFillAttribute |= BACKGROUND_BLUE;
    }
    else if (sUpCaseParam == _T("FS"))
      dwFlags |= STARTF_RUNFULLSCREEN;
    else if (sUpCaseParam == _T("LP"))
      dwLogonFlags = LOGON_WITH_PROFILE;
    else if (sUpCaseParam == _T("LNCO"))
      dwLogonFlags = LOGON_NETCREDENTIALS_ONLY;
    else if ((sUpCaseParam.Find(_T("AFFINITY")) == 0) && (nLength > 8))
    {
      CString sAffinity{sUpCaseParam.Right(nLength - 8)};
    #ifdef _WIN64
      _stscanf_s(sAffinity, _T("%I64u"), &dwProcessAffinity);
    #else
      _stscanf_s(sAffinity, _T("%u"), &dwProcessAffinity);
    #endif //#ifdef _WIN64
    }
    else if ((sUpCaseParam.Find(_T("NODE")) == 0) && (nLength > 4))
    {
      CString sNode{sUpCaseParam.Right(nLength - 4)};
      _stscanf_s(sNode, _T("%d"), &nNode);
    }
  }
}


#pragma warning(suppress: 26433 26440)
BEGIN_MESSAGE_MAP(CStartXApp, CWinApp) //NOLINT(clang-diagnostic-unused-local-typedef, modernize-avoid-c-arrays)
END_MESSAGE_MAP()

CString CStartXApp::GetErrorDescription(_In_ DWORD dwError)
{
  //What will be the return value from this function
  CString sError;

  LPTSTR lpBuffer{nullptr};
#pragma warning(suppress: 26490)
  if (FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                    nullptr, dwError, MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT),
                    reinterpret_cast<LPTSTR>(&lpBuffer), 0, nullptr))
  {
    sError = lpBuffer;
    LocalFree(lpBuffer);
  }

  return sError;
}

void CStartXApp::SecureEmptyString(_Inout_ CString& sVal)
{
  const int nLength{sVal.GetLength()};
  LPTSTR pszVal{sVal.GetBuffer(nLength)};
  SecureZeroMemory(pszVal, nLength*sizeof(TCHAR));
  sVal.ReleaseBuffer();
}

BOOL CStartXApp::InitInstance()
{
  //Find the current directory and drive for this instance
  CString sPath;
  const DWORD dwGMF{GetModuleFileName(nullptr, sPath.GetBuffer(_MAX_PATH), _MAX_PATH)};
  sPath.ReleaseBuffer();
  if (dwGMF == 0) //NOLINT(clang-analyzer-core.CallAndMessage)
  {
    m_nReturnCode = GetLastError();
    return FALSE;
  }
  CString sDrive;
  CString sDir;
  _tsplitpath_s(sPath, sDrive.GetBuffer(_MAX_DRIVE), _MAX_DRIVE, sDir.GetBuffer(_MAX_DIR), _MAX_DIR, nullptr, 0, nullptr, 0);
  sDrive.ReleaseBuffer();
  sDir.ReleaseBuffer();
  CString sFolder;
  _tmakepath_s(sFolder.GetBuffer(_MAX_PATH), _MAX_PATH, sDrive, sDir, nullptr, nullptr);
  sFolder.ReleaseBuffer();
  int nLength{sFolder.GetLength()};
  if (nLength && sFolder.GetAt(nLength-1) == _T('\\'))
    sFolder = sFolder.Left(nLength-1);
  nLength = sDrive.GetLength();
  if (nLength && sDrive.GetAt(nLength-1) == _T('\\'))
    sDrive = sDrive.Left(nLength-1);

  //Parse the command line
  CMyCommandLineInfo cmdInfo;
  cmdInfo.sDrive = sDrive;
  cmdInfo.sFolder = sFolder;
  ParseCommandLine(cmdInfo);
  if (cmdInfo.sCommandLine.IsEmpty())
  {
    //Display an error message if we failed to parse the command line
    CParametersPromptDlg dlg;
    dlg.DoModal();
    return FALSE;
  }

  const bool bCreateProcessWithLogon{cmdInfo.sUser.GetLength() || cmdInfo.bPromptPassword};

  //Do we need to call CredUIPromptForCredentials
  if (cmdInfo.bPromptPassword)
  {
    //Do the actual prompting for the user
    CString sUserName{cmdInfo.sUser};
    CString sPassword{cmdInfo.sPassword};
    BOOL bSave{FALSE};

    //Form the prompts to display in the dialog
    CREDUI_INFO cuii{};
    cuii.cbSize = sizeof(CREDUI_INFO);
    CString sMessagePrompt;

    CString sProgram{cmdInfo.sCommandLine};
    sProgram.TrimLeft();
    const int nSpace{sProgram.Find(_T(" "))};
    if (nSpace != -1)
      sProgram = sProgram.Left(nSpace);
    AfxFormatString1(sMessagePrompt, IDS_MESSAGE_PROMPT, sProgram);
    cuii.pszMessageText = sMessagePrompt;
    CString sMessageCaption;
    if (sMessageCaption.LoadString(IDS_MESSAGE_CAPTION))
      cuii.pszCaptionText = sMessageCaption;

    //Display the standard dialog to prompt for credentials
    const DWORD dwError{CredUIPromptForCredentials(&cuii, nullptr, nullptr, 0, sUserName.GetBuffer(CREDUI_MAX_USERNAME_LENGTH + 1), CREDUI_MAX_USERNAME_LENGTH + 1,
                                                   sPassword.GetBuffer(CREDUI_MAX_PASSWORD_LENGTH + 1), CREDUI_MAX_PASSWORD_LENGTH + 1, &bSave,
                                                   CREDUI_FLAGS_INCORRECT_PASSWORD | CREDUI_FLAGS_DO_NOT_PERSIST | CREDUI_FLAGS_USERNAME_TARGET_CREDENTIALS)};
    sUserName.ReleaseBuffer();
    sPassword.ReleaseBuffer();
    if (dwError == NO_ERROR)
    {
      //Transfer the values back to the structure
      cmdInfo.sUser = sUserName;
      cmdInfo.sPassword = sPassword;
    }
    else
    {
      m_nReturnCode = dwError;

      if (dwError != ERROR_CANCELLED)
      {
        if (!cmdInfo.bNoUI)
        {
          CString sError;
          sError.Format(_T("%u"), dwError);
          CString sMsg;
          AfxFormatString2(sMsg, IDP_FAIL_RUN_CREDUIPROMPTFORCREDENTIALS, sError, GetErrorDescription(dwError));
          AfxMessageBox(sMsg);
        }
      }

      return FALSE;
    }
  }

  //Do we need to call GetNumaNodeProcessorMaskEx
  GROUP_AFFINITY groupAffinity{};
  if (cmdInfo.nNode != -1)
  {
#pragma warning(suppress: 26472)
    if (!GetNumaNodeProcessorMaskEx(static_cast<USHORT>(cmdInfo.nNode), &groupAffinity))
    {
      m_nReturnCode = GetLastError();
      if (!cmdInfo.bNoUI)
      {
        CString sError;
        sError.Format(_T("%u"), m_nReturnCode);
        CString sMsg;
        AfxFormatString2(sMsg, IDP_FAIL_RUN_GETNUMANODEPROCESSORMASKEX, sError, GetErrorDescription(m_nReturnCode));
        AfxMessageBox(sMsg);
      }
      return FALSE;
    }
  }

  //Fill in the STARTUPINFO structure
  STARTUPINFO si{};
  STARTUPINFOW siw{};
  CStringW sDesktop;
  CStringW sTitle;
  if (bCreateProcessWithLogon)
  {
    siw.cb = sizeof(STARTUPINFOW);
    if (cmdInfo.bDesktop && cmdInfo.sDesktop.GetLength())
    {
      sDesktop = cmdInfo.sDesktop;
      siw.lpDesktop = sDesktop.GetBuffer(sDesktop.GetLength());
    }
    if (cmdInfo.sConsoleTitle.GetLength())
    {
      sTitle = cmdInfo.sConsoleTitle;
      siw.lpTitle = sTitle.GetBuffer(sTitle.GetLength());
    }
    siw.dwFlags = cmdInfo.dwFlags;
    if (siw.dwFlags & STARTF_USEPOSITION)
    {
      siw.dwX = cmdInfo.WindowPoint.x;
      siw.dwY = cmdInfo.WindowPoint.y;
    }
    if (siw.dwFlags & STARTF_USESIZE)
    {
      siw.dwXSize = cmdInfo.WindowSize.cx;
      siw.dwYSize = cmdInfo.WindowSize.cy;
    }
    if (siw.dwFlags & STARTF_USECOUNTCHARS)
    {
      siw.dwXCountChars = cmdInfo.ConsoleBufferSize.cx;
      siw.dwYCountChars = cmdInfo.ConsoleBufferSize.cy;
    }
    if (siw.dwFlags & STARTF_USEFILLATTRIBUTE)
      siw.dwFillAttribute = cmdInfo.dwFillAttribute;
    siw.wShowWindow = cmdInfo.wShowWindow;
  }
  else
  {
    si.cb = sizeof(STARTUPINFO);
    if (cmdInfo.bDesktop && cmdInfo.sDesktop.GetLength())
      si.lpDesktop = cmdInfo.sDesktop.GetBuffer(cmdInfo.sDesktop.GetLength());
    if (cmdInfo.sConsoleTitle.GetLength())
      si.lpTitle = cmdInfo.sConsoleTitle.GetBuffer(cmdInfo.sConsoleTitle.GetLength());
    si.dwFlags = cmdInfo.dwFlags;
    if (si.dwFlags & STARTF_USEPOSITION)
    {
      si.dwX = cmdInfo.WindowPoint.x;
      si.dwY = cmdInfo.WindowPoint.y;
    }
    if (si.dwFlags & STARTF_USESIZE)
    {
      si.dwXSize = cmdInfo.WindowSize.cx;
      si.dwYSize = cmdInfo.WindowSize.cy;
    }
    if (si.dwFlags & STARTF_USECOUNTCHARS)
    {
      si.dwXCountChars = cmdInfo.ConsoleBufferSize.cx;
      si.dwYCountChars = cmdInfo.ConsoleBufferSize.cy;
    }
    if (si.dwFlags & STARTF_USEFILLATTRIBUTE)
      si.dwFillAttribute = cmdInfo.dwFillAttribute;
    si.wShowWindow = cmdInfo.wShowWindow;
  }

  PROCESS_INFORMATION pi{};
  bool bSuccess = false;
  if (bCreateProcessWithLogon)
  {
    CStringW sUnicodeCommandLine{cmdInfo.sCommandLine};
    const int nCurrentDirectory{cmdInfo.sCurrentDirectory.GetLength()};
    CStringW sUnicodeCurrentDirectory{cmdInfo.sCurrentDirectory};
    bSuccess = (CreateProcessWithLogonW(CStringW{cmdInfo.sDomain}, cmdInfo.sDomain.GetLength() ? CStringW{cmdInfo.sDomain} : nullptr, CStringW{cmdInfo.sPassword}, cmdInfo.dwLogonFlags, nullptr,
                                        sUnicodeCommandLine.GetBuffer(), cmdInfo.dwCreationFlags, nullptr, nCurrentDirectory ? sUnicodeCurrentDirectory.GetBuffer() : nullptr, &siw, &pi) != 0);
    sUnicodeCommandLine.ReleaseBuffer();
    if (nCurrentDirectory)
      sUnicodeCurrentDirectory.ReleaseBuffer();
    if (cmdInfo.sConsoleTitle.GetLength())
      sTitle.ReleaseBuffer();
    if (cmdInfo.bDesktop && cmdInfo.sDesktop.GetLength())
      sDesktop.ReleaseBuffer();
  }
  else
  {
    LPTSTR pszCommandLine{cmdInfo.sCommandLine.GetBuffer(cmdInfo.sCommandLine.GetLength())};
#pragma warning(suppress: 26486)
    bSuccess = (CreateProcess(nullptr, pszCommandLine, nullptr, nullptr, FALSE, cmdInfo.dwCreationFlags, nullptr, cmdInfo.sCurrentDirectory.GetLength() ? cmdInfo.sCurrentDirectory.GetString() : nullptr, &si, &pi) != 0);
    cmdInfo.sCommandLine.ReleaseBuffer();
    if (cmdInfo.sConsoleTitle.GetLength())
      cmdInfo.sConsoleTitle.ReleaseBuffer();
    if (cmdInfo.bDesktop && cmdInfo.sDesktop.GetLength())
      cmdInfo.sDesktop.ReleaseBuffer();
  }

  //Securely nuke the domain, username and password strings now that we are finished with them
  SecureEmptyString(cmdInfo.sDomain);
  SecureEmptyString(cmdInfo.sUser);
  SecureEmptyString(cmdInfo.sPassword);

  if (!bSuccess)
  {
    m_nReturnCode = GetLastError();
    if (!cmdInfo.bNoUI)
    {
      CString sError;
      sError.Format(_T("%u"), m_nReturnCode);
      CString sMsg;
      AfxFormatString2(sMsg, IDP_FAIL_RUN_CREATEPROCESS, sError, GetErrorDescription(m_nReturnCode));
      AfxMessageBox(sMsg);
    }
  }
  else
  {
    //Set the numa node if required to
    if (cmdInfo.nNode != -1)
    {
      if (!SetProcessAffinityMask(pi.hProcess, groupAffinity.Mask))
      {
        m_nReturnCode = GetLastError();
        if (!cmdInfo.bNoUI)
        {
          CString sError;
          sError.Format(_T("%u"), m_nReturnCode);
          CString sMsg;
          AfxFormatString2(sMsg, IDP_FAIL_SET_PROCESS_AFFINITY, sError, GetErrorDescription(m_nReturnCode));
          AfxMessageBox(sMsg);
        }
      }
    }

    //Set processor affinity if required to
    if (cmdInfo.dwProcessAffinity)
    {
      if (!SetProcessAffinityMask(pi.hProcess, cmdInfo.dwProcessAffinity))
      {
        m_nReturnCode = GetLastError();
        if (!cmdInfo.bNoUI)
        {
          CString sError;
          sError.Format(_T("%u"), m_nReturnCode);
          CString sMsg;
          AfxFormatString2(sMsg, IDP_FAIL_SET_PROCESS_AFFINITY, sError, GetErrorDescription(m_nReturnCode));
          AfxMessageBox(sMsg);
        }
      }
    }
      
    //Should we wait for the app to exit
    if (cmdInfo.bWait)
    {
      WaitForSingleObject(pi.hProcess, INFINITE);

      //Get the exit code of the process if required
      if (cmdInfo.bReturnError)
      {
        DWORD dwExitCode{ERROR_SUCCESS};
        if (GetExitCodeProcess(pi.hProcess, &dwExitCode))
          m_nReturnCode = dwExitCode;
      }
    }

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
  }

  return FALSE;
}

int CStartXApp::ExitInstance()
{
  //Let the base class do its thing
  __super::ExitInstance();

  //Return the error code we have cached
  return m_nReturnCode;
}
