/*
Module : StartX.h
Purpose: Implementation of a simple CreateProcess wrapper app
Created: PJN / 29-01-2003

Copyright (c) 2003 - 2021 by PJ Naughter.  (Web: www.naughter.com, Email: pjna@naughter.com)

All rights reserved.

Copyright / Usage Details:

You are allowed to include the source code in any product (commercial, shareware, freeware or otherwise) 
when your product is released in binary form. You are allowed to modify the source code in any way you want 
except you cannot modify the copyright details at the top of each module. If you want to distribute source 
code with your application, then you are only allowed to distribute versions released by the author. This is 
to maintain a single distribution point for the source code. 

*/

//////////////////////////// Macros / Defines /////////////////////////////////

#pragma once


//////////////////// Classes //////////////////////////////////////////////////

class CStartXApp : public CWinApp
{
public:
//Methods
  BOOL InitInstance() override;
  int ExitInstance() override;

protected:
//Methods
  static CString GetErrorDescription(_In_ DWORD dwError);
  __forceinline static void SecureEmptyString(_Inout_ CString& sVal);

//Member variables
  UINT m_nReturnCode{ERROR_SUCCESS};

  DECLARE_MESSAGE_MAP()
};
