#pragma once

#ifndef __AFXWIN_H__
  #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"


class CShelExecApp : public CWinApp
{
public:
//Methods
  BOOL InitInstance() override;
  int ExitInstance() override;

protected:
//Methods
  static CString FormatMessage(_In_ DWORD dwError);

//Member variables
  DWORD m_nReturnCode{ERROR_SUCCESS};

  DECLARE_MESSAGE_MAP()
};
