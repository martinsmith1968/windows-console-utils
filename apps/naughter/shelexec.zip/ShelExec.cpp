/*
Module : ShelExec.cpp
Purpose: Implementation of a simple ShellExecute wrapper app

Copyright (c) 1999 - 2022 by PJ Naughter (Web: www.naughter.com, Email: pjna@naughter.com)

All rights reserved.

Copyright / Usage Details:

You are allowed to include the source code in any product (commercial, shareware, freeware or otherwise) 
when your product is released in binary form. You are allowed to modify the source code in any way you want 
except you cannot modify the copyright details at the top of each module. If you want to distribute source 
code with your application, then you are only allowed to distribute versions released by the author. This is 
to maintain a single distribution point for the source code.
*/


//////////////////// Includes /////////////////////////////////////////////////

#include "stdafx.h"
#include "ShelExec.h"


//////////////////// Macros / Defines /////////////////////////////////////////

#ifdef _DEBUG
#define new DEBUG_NEW
#endif //#ifdef _DEBUG


//////////////////// Implementation ///////////////////////////////////////////

class CEnumDisplayArg
{
public:
//Member variables
  CString  m_sMonitor; //The name of the monitor to match
  HMONITOR m_hMon{nullptr}; //If found the monitor handle
};


class CMyCommandLineInfo : public CCommandLineInfo
{
public:
//Methods
  void ParseParam(const TCHAR* pszParam, BOOL bFlag, BOOL bLast) override;

//Data
  CString m_sVerb;
  CString m_sDir;
  int m_nCmdShow{SW_SHOW};
  bool m_bExe{false};
  CString m_sParams;
  bool m_bWait{false};
  bool m_bNoShortFileNameConversion{false};
  bool m_bNoUI{false};
  bool m_bWaitForInputIdle{false};
  CString m_sMonitor;
};


//Callback function used to find the correct monitor handle
#pragma warning(suppress: 26440)
BOOL CALLBACK EnumDispProc(HMONITOR hMon, HDC /*dcMon*/, RECT* /*pRcMon*/, LPARAM lParam)
{
#pragma warning(suppress: 26490)
  auto pArg{reinterpret_cast<CEnumDisplayArg*>(lParam)};
#pragma warning(suppress: 26496)
  AFXASSUME(pArg != nullptr);

  MONITORINFOEX miex;
  miex.cbSize = sizeof(miex);
  if (GetMonitorInfo(hMon, &miex))
  {
#pragma warning(suppress: 26485 26489)
    if (pArg->m_sMonitor == miex.szDevice)
    {
#pragma warning(suppress: 26489)
      pArg->m_hMon = hMon;
      return FALSE;
    }
  }

  return TRUE;
}


void CMyCommandLineInfo::ParseParam(const TCHAR* pszParam, BOOL bFlag, BOOL bLast)
{
  if (bFlag)
  {
    CString sParam{pszParam};
    CString sUpCaseParam{pszParam};
    sUpCaseParam.MakeUpper();

    //Handle the various command line parameters we support
    const int nLength{sUpCaseParam.GetLength()};
    if ((sUpCaseParam.Find(_T("SHOWCMD")) == 0) && (nLength > 8))
    {
      CString sShowVal(sParam.Right(nLength - 8));
      m_nCmdShow = _ttoi(sShowVal);
    }
    else if ((sUpCaseParam.Find(_T("VERB")) == 0) && (nLength > 5))
      m_sVerb = sParam.Right(nLength - 5);
    else if ((sUpCaseParam.Find(_T("DIR")) == 0) && (nLength > 4))
      m_sDir = sParam.Right(nLength - 4);
    else if ((sUpCaseParam.Find(_T("PARAMS")) == 0) && (nLength > 7))
      m_sParams = sParam.Right(nLength - 7);
    else if (sUpCaseParam == _T("WAIT"))
      m_bWait = true;
    else if (sUpCaseParam == _T("WAITFORINPUTIDLE"))
      m_bWaitForInputIdle = true;
    else if (sUpCaseParam == _T("NOSFNC"))
      m_bNoShortFileNameConversion = true;
    else if (sParam == _T("EXE"))
      m_bExe = true;
    else if (sUpCaseParam == _T("NOUI"))
      m_bNoUI = true;
    else if ((sUpCaseParam.Find(_T("MONITOR")) == 0) && (nLength > 8))
      m_sMonitor = sParam.Right(nLength - 8);
    else
    {
      //Let the base class do its thing
      __super::ParseParam(pszParam, bFlag, bLast);
    }
  }
  else
  {
    //Let the base class do its thing
    __super::ParseParam(pszParam, bFlag, bLast);
  }
}


#pragma warning(suppress: 26433 26440)
BEGIN_MESSAGE_MAP(CShelExecApp, CWinApp) //NOLINT(clang-diagnostic-unused-local-typedef, modernize-avoid-c-arrays)
END_MESSAGE_MAP()

#pragma warning(suppress: 26426)
CShelExecApp theApp;


BOOL CShelExecApp::InitInstance()
{
  //Parse the command line
  CMyCommandLineInfo cmdInfo;
  ParseCommandLine(cmdInfo);

  //Show the usage if no filename was specified
  if (cmdInfo.m_strFileName.IsEmpty()) //NOLINT(clang-analyzer-core.CallAndMessage)
  {
    m_nReturnCode = ERROR_INVALID_PARAMETER;

  #ifdef _CONSOLE
    if (!cmdInfo.m_bNoUI)
    {
      CString sMsg;
      const BOOL bLoaded{sMsg.LoadString(IDP_USAGE)};
      UNREFERENCED_PARAMETER(bLoaded);
      _tprintf(_T("%s\n"), sMsg.GetString());
    }
  #else
    if (!cmdInfo.m_bNoUI)
      AfxMessageBox(IDP_USAGE);
  #endif //#ifdef _CONSOLE
    return FALSE;
  }

  //Find the current directory and drive for this instance
  CString sPath;
  const DWORD dwGMF{GetModuleFileName(nullptr, sPath.GetBuffer(_MAX_PATH), _MAX_PATH)};
  sPath.ReleaseBuffer();
  if (dwGMF == 0)
  {
    m_nReturnCode = GetLastError();

    //Report the error if required
    CString sErrorCode;
    sErrorCode.Format(_T("%u"), m_nReturnCode);
    CString sMsg;
    AfxFormatString2(sMsg, IDP_FAIL_GETMODULEFILENAME, sErrorCode, FormatMessage(m_nReturnCode));
  #ifdef _CONSOLE
    if (!cmdInfo.m_bNoUI)
      _tprintf(_T("%s\n"), sMsg.GetString());
  #else
    if (!cmdInfo.m_bNoUI)
      AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
  #endif //#ifdef _CONSOLE
    return FALSE;
  }
  CString sDrive;
  CString sDir;
  _tsplitpath_s(sPath, sDrive.GetBuffer(_MAX_DRIVE), _MAX_DRIVE, sDir.GetBuffer(_MAX_DIR), _MAX_DIR, nullptr, 0, nullptr, 0);
  sDrive.ReleaseBuffer();
  sDir.ReleaseBuffer();
  CString sFolder;
  _tmakepath_s(sFolder.GetBuffer(_MAX_PATH), _MAX_PATH, sDrive, sDir, nullptr, nullptr);
  sFolder.ReleaseBuffer();
  int nLength{sFolder.GetLength()};
  if (nLength && sFolder.GetAt(nLength - 1) == _T('\\'))
    sFolder = sFolder.Left(nLength - 1);
  nLength = sDrive.GetLength();
  if (nLength && sDrive.GetAt(nLength - 1) == _T('\\'))
    sDrive = sDrive.Left(nLength - 1);

  //Replace any variables with their actual values as determined above
  cmdInfo.m_sDir.Replace(_T("@EXEDRV@"), sDrive);
  cmdInfo.m_sParams.Replace(_T("@EXEDRV@"), sDrive);
  cmdInfo.m_strFileName.Replace(_T("@EXEDRV@"), sDrive);

  cmdInfo.m_sDir.Replace(_T("@EXEDIR@"), sFolder);
  cmdInfo.m_sParams.Replace(_T("@EXEDIR@"), sFolder);
  cmdInfo.m_strFileName.Replace(_T("@EXEDIR@"), sFolder);

  cmdInfo.m_sDir.Replace(_T("@QUOTE@"), _T("\""));
  cmdInfo.m_sParams.Replace(_T("@QUOTE@"), _T("\""));
  cmdInfo.m_strFileName.Replace(_T("@QUOTE@"), _T("\""));

  //The structure which will be passed to ShellExecuteEx
  SHELLEXECUTEINFO sei;
  memset(&sei, 0, sizeof(sei));
  sei.cbSize = sizeof(sei);

  //Convert the filename to its short version if we did not specify no short filename conversion
  if (!cmdInfo.m_bNoShortFileNameConversion)
  {
    //convert to short filename format if we can
    GetShortPathName(cmdInfo.m_strFileName, cmdInfo.m_strFileName.GetBuffer(_MAX_PATH), _MAX_PATH);
    cmdInfo.m_strFileName.ReleaseBuffer();
  }

  //Setup the structure with common parameters
  sei.nShow = cmdInfo.m_nCmdShow;
  sei.lpFile = cmdInfo.m_strFileName.GetBuffer(cmdInfo.m_strFileName.GetLength());
  sei.fMask = SEE_MASK_DOENVSUBST | SEE_MASK_NOASYNC | SEE_MASK_INVOKEIDLIST;
  if (cmdInfo.m_bWait)
    sei.fMask |= SEE_MASK_NOCLOSEPROCESS;
  if (cmdInfo.m_bNoUI)
    sei.fMask |= SEE_MASK_FLAG_NO_UI;
  if (cmdInfo.m_bWaitForInputIdle)
    sei.fMask |= SEE_MASK_WAITFORINPUTIDLE;

  //Get the monitor handle if required
  if (cmdInfo.m_sMonitor.GetLength())
  {
    CEnumDisplayArg dispArg;
    dispArg.m_sMonitor = cmdInfo.m_sMonitor;
#pragma warning(suppress: 26490)
    EnumDisplayMonitors(nullptr, nullptr, EnumDispProc, reinterpret_cast<LPARAM>(&dispArg));
    if (dispArg.m_hMon == nullptr)
    {
      m_nReturnCode = ERROR_FILE_NOT_FOUND;

      //Report the error if required
      CString sMsg;
      AfxFormatString1(sMsg, IDP_FAIL_FIND_MONITOR, cmdInfo.m_sMonitor);
    #ifdef _CONSOLE
      if (!cmdInfo.m_bNoUI)
        _tprintf(_T("%s\n"), sMsg.GetString());
    #else
      if (!cmdInfo.m_bNoUI)
        AfxMessageBox(sMsg, MB_OK | MB_ICONEXCLAMATION);
    #endif //#ifdef _CONSOLE
      return FALSE;
    }

#pragma warning(suppress: 26489)
    sei.hMonitor = dispArg.m_hMon;
    sei.fMask |= SEE_MASK_HMONITOR;
  }

  //Did we specify a working directory
  if (cmdInfo.m_sDir.GetLength())
    sei.lpDirectory = cmdInfo.m_sDir.GetBuffer(cmdInfo.m_sDir.GetLength());

  //Set any optional parameters
  if (cmdInfo.m_bExe)
  {
    if (cmdInfo.m_sParams.GetLength())
      sei.lpParameters = cmdInfo.m_sParams.GetBuffer(cmdInfo.m_sParams.GetLength());
  }
  else
  {
    if (cmdInfo.m_sVerb.GetLength())
      sei.lpVerb = cmdInfo.m_sVerb.GetBuffer(cmdInfo.m_sVerb.GetLength());
  }

  //Call ShellExecuteEx API
#pragma warning(suppress: 26486)
  ShellExecuteEx(&sei);
  m_nReturnCode = GetLastError();

  //Release all our CString buffers
  cmdInfo.m_strFileName.ReleaseBuffer();
  if (cmdInfo.m_sDir.GetLength())
    cmdInfo.m_sDir.ReleaseBuffer();
  if (cmdInfo.m_bExe)
  {
    if (cmdInfo.m_sParams.GetLength())
      cmdInfo.m_sParams.ReleaseBuffer();
  }
  else
  {
    if (cmdInfo.m_sVerb.GetLength())
      cmdInfo.m_sVerb.ReleaseBuffer();
  }

  //Wait for the process to exit if required
  if (cmdInfo.m_bWait)
  {
    if (sei.hProcess != nullptr)
      WaitForSingleObject(sei.hProcess, INFINITE);
  }

  //Close the process handle if required
  if (sei.hProcess != nullptr)
    CloseHandle(sei.hProcess);

  return FALSE;
}

int CShelExecApp::ExitInstance()
{
  //Let the base class do its thing
  __super::ExitInstance();

  //Return the error code we have cached
  return m_nReturnCode;
}

CString CShelExecApp::FormatMessage(_In_ DWORD dwError)
{
  //What will be the return value from this method
  CString sError;

  //Lookup the error using FormatMessage
  LPTSTR lpszError{nullptr};
#pragma warning(suppress: 26490)
  const DWORD dwReturn{::FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                                       nullptr, dwError, MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT), reinterpret_cast<LPTSTR>(&lpszError), 0, nullptr)};
  if (dwReturn)
  {
    sError = lpszError;
    LocalFree(lpszError);
  }

  return sError;
}
